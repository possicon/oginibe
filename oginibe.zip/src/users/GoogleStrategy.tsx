export class GoogleStrategy {}
