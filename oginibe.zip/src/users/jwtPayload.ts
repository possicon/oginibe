export interface JwtPayload {
  id: string;
}
